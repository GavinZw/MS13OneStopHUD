//
//  MS13V_LaunchViewController.h
//  MS13HUD
//
//  Created by GaviniMacBook on 2017/12/6.
//  Copyright © 2017年 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MS13V_LaunchViewController : UIViewController

@end
